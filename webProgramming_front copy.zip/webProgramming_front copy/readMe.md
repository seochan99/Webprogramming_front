# 웹프로그래밍 Node.js 실행 Front 코드
##  🤔 How To build It?
```
npm i 
npm run dev
```
## First Setting
### 1. 환경변수 설정
>src폴더 밖에 .env 파일에 본인 server주소 기입
>>[**예시**]
>VITE_APP_SERVER_PORT = "http://localhost:5050/"

